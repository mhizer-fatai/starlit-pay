pragma circom 2.2.2;

// Selective Disclosure Circuit
include "./merkleProof.circom";
include "./poseidon2/poseidon2_hash.circom";
include "./keypair.circom";
include "./circomlib/circuits/comparators.circom";

// Allows a user to demonstrate ownership of a note commitment without revealing its secrets
// * levels: Number of levels in the Merkle tree that holds the note commitments
// * nNotes: Number of notes to prove ownership of.
// Right now we allow proving ownership of multiple notes on different roots BUT for the same external context:
// - Purpose
// - Authority
// - Pool address
// So that you can prove multiple notes
template SelectiveDisclosure(levels, nNotes) {
    /** PUBLIC INPUTS **/
    signal input roots[nNotes];
    signal input noteCommitments[nNotes];
    signal input extContextHash;
    // Nullifier, re-computed in-circuit
    signal input expectedNullifier[nNotes];
    // Disclosed note amounts
    signal input inAmount[nNotes];

    /** PRIVATE INPUTS **/
    signal input inPrivateKey[nNotes];
    signal input inBlinding[nNotes];
    signal input inPathIndices[nNotes];
    signal input inPathElements[nNotes][levels];

    // Components
    component inKeypair[nNotes];
    component inCommitmentHasher[nNotes];
    component inSignature[nNotes];
    component inNullifierHasher[nNotes];
    component inTree[nNotes];

    for (var ni = 0; ni < nNotes; ni++) {
        // Verify that the sender actually owns the inputs
        // He knows the secret keys and the blinding factors.
        inKeypair[ni] = Keypair();
        inKeypair[ni].privateKey <== inPrivateKey[ni];

        // Computes the leaf commitment as hash(amount, publicKey, blinding)
        inCommitmentHasher[ni] = Poseidon2(3);
        inCommitmentHasher[ni].inputs[0] <== inAmount[ni];
        inCommitmentHasher[ni].inputs[1] <== inKeypair[ni].publicKey;
        inCommitmentHasher[ni].inputs[2] <== inBlinding[ni];
        inCommitmentHasher[ni].domainSeparation <== 0x01; // Leaf commitment

        // Ensures it matches the claimed note
        noteCommitments[ni] === inCommitmentHasher[ni].out;

        // Computes the signature as hash(privateKey, commitment, merklePath)
        inSignature[ni] = Signature();
        inSignature[ni].privateKey <== inPrivateKey[ni];
        inSignature[ni].commitment <== inCommitmentHasher[ni].out;
        inSignature[ni].merklePath <== inPathIndices[ni];

        // Computes and constrains the nullifier as hash(commitment, merklePath, signature)
        inNullifierHasher[ni] = Poseidon2(3);
        inNullifierHasher[ni].inputs[0] <== inCommitmentHasher[ni].out;
        inNullifierHasher[ni].inputs[1] <== inPathIndices[ni];
        inNullifierHasher[ni].inputs[2] <== inSignature[ni].out;
        inNullifierHasher[ni].domainSeparation <== 0x02;
        // Ensure it matches the provided nullifier
        expectedNullifier[ni] === inNullifierHasher[ni].out;

        // Verifies the merkle proofs
        inTree[ni] = MerkleProof(levels);
        inTree[ni].leaf <== inCommitmentHasher[ni].out;
        inTree[ni].pathIndices <== inPathIndices[ni];
        for (var i = 0; i < levels; i++) {
            inTree[ni].pathElements[i] <== inPathElements[ni][i];
        }
        // Ensure root matches the expected value
        roots[ni] === inTree[ni].root;
    }

    // Refuse a note repeated across slots, which would count its amount twice
    component sameNullifiers[nNotes * (nNotes - 1) / 2];
    var index = 0;
    for (var i = 0; i < nNotes - 1; i++) {
        for (var j = i + 1; j < nNotes; j++) {
            sameNullifiers[index] = IsEqual();
            sameNullifiers[index].in[0] <== expectedNullifier[i];
            sameNullifiers[index].in[1] <== expectedNullifier[j];
            sameNullifiers[index].out === 0;
            index++;
        }
    }

    // Safety constraint to bind external context
    signal extContextSquare <== extContextHash * extContextHash;
}
