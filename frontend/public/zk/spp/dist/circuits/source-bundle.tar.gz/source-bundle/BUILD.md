# Corresponding Source for the circuit artifacts served by Starlit Pay

The compiled circuit artifacts (`*.r1cs`, `*.graph.bin`) and proving keys that
Starlit Pay serves under `/zk/spp/dist/circuits/` were built from:

- Stellar Private Payments, commit b37c5b8ae1c8d33a8ab0cc427756a734bfec19c0
  https://github.com/NethermindEth/stellar-private-payments/tree/b37c5b8ae1c8d33a8ab0cc427756a734bfec19c0/circuits
  (its Circom sources are identical to commit 801b311d22aff86f1b0802b6de4946758f5c2fef,
  recorded in circuits.json, and to release circuits-v0.7)
- iden3/circomlib, revision 35e54ea21da3e8762557234298dbb553c175ea8d (LGPL-3.0)
  https://github.com/iden3/circomlib/tree/35e54ea21da3e8762557234298dbb553c175ea8d

Contents of this bundle:

- `circuits/`  the SPP `circuits/` directory at the commit above
- `circomlib/` circomlib at the revision above (see `circomlib/LICENSE`)

To rebuild, follow the "Install the CLI" and circuit build instructions in the
SPP README at the commit above (`make circuits`), with circomlib placed at
`circuits/src/circomlib`. Starlit builds the browser SDK with the workflow
`.github/workflows/spp-sdk.yml` in https://github.com/mhizer-fatai/starlit-pay.

Licenses: SPP sources are Apache-2.0 (see `circuits/LICENSE`); circomlib is
LGPL-3.0, which requires a copy of GPL-3.0 (see `../licenses/`).
